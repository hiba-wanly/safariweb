
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:safariweb/places/bloc/places_states.dart';



class PlacesCubit extends Cubit<PlacesState>
{
  PlacesCubit(PlacesState initialState) : super(initialState);

  static PlacesCubit get(context) => BlocProvider.of(context);

}