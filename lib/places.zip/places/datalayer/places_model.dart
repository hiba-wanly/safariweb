class AddPlaces{
  late String name;
  late String description;
  late String country;
  late int meridian;
  late int latitudes;
  late int stars;
  late String fromday;
  late String today;
  late int fromtime;
  late int totime;
  late int price;
  AddPlaces({
    required this.name,
    required this.description,
    required this.country,
    required this.meridian,
    required this.latitudes,
    required this.stars,
    required this.fromday,
    required this.today,
    required this.fromtime,
    required this.totime,
    required this.price
  });
}